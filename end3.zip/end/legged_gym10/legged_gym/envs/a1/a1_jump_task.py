from legged_gym.envs.base.legged_robot_config import LeggedRobotCfg, LeggedRobotCfgPPO

class A1JumpCfg(LeggedRobotCfg):
    class env_cfg:
        num_envs = 4096
        env_spacing = 3.0
        episode_length_s = 20

    class init_state:
        pos = [0.0, 0.0, 0.42]  # Начальная позиция робота
        default_joint_angles = {  # Начальные углы суставов
            "FL_hip_joint": 0.0,
            "RL_hip_joint": 0.0,
            "FR_hip_joint": 0.0,
            "RR_hip_joint": 0.0,
        }

    class control_cfg:
        control_type = "P"
        stiffness = {"joint": 20.0}  # Жесткость суставов
        damping = {"joint": 0.5}  # Демпфирование суставов
        action_scale = 0.5  # Масштабирование действий
        decimation = 4

    class asset:
        file = '{LEGGED_GYM_ROOT_DIR}/resources/a1/urdf/a1.urdf'
        name = "a1"
        foot_name = "foot"
        penalize_contacts_on = ["thigh", "calf"]
        terminate_after_contacts_on = ["base"]
        self_collisions = 1  # Включение самоколлизий
        default_dof_drive_mode = 3  # Установка режима привода по умолчанию
        collapse_fixed_joints = True  # Добавление атрибута collapse_fixed_joints
        replace_cylinder_with_capsule = True  # Добавление атрибута replace_cylinder_with_capsule
        flip_visual_attachments = False  # Добавление атрибута flip_visual_attachments

    class rewards:
        base_height = {
            "weight": 1.0,
            "target_height": 0.5,  # Целевая высота прыжка
        }
        termination = {"weight": -200.0}
        tracking_lin_vel = {"weight": 1.0}
        scales = {  # Добавление весов вознаграждений
            "base_height": 1.0,
            "termination": -200.0,
            "tracking_lin_vel": 1.0,
        }

    class normalization:
        clip_observations = 100.0
        clip_actions = 100.0
        obs_scales = {
            "lin_vel": 2.0,
            "ang_vel": 0.25,
            "dof_pos": 1.0,
            "dof_vel": 0.05,
            "actions": 1.0,
        }

    class noise:
        add_noise = False
        noise_level = 1.0
        noise_scales = {
            "dof_pos": 0.01,
            "dof_vel": 1.5,
            "lin_vel": 0.1,
            "ang_vel": 0.1,
            "gravity": 0.05,
            "actions": 0.1,
        }

class A1JumpPPOCfg(LeggedRobotCfgPPO):
    class policy:
        init_noise_std = 1.0
        actor_hidden_dims = [256, 256]
        critic_hidden_dims = [256, 256]
        activation = 'tanh'

    class algorithm:
        value_loss_coef = 2.0
        use_clipped_value_loss = True
        clip_param = 0.2
        entropy_coef = 0.01
        num_learning_epochs = 5
        num_mini_batches = 4
        learning_rate = 1.e-3
        schedule = 'fixed'

    class runner:
        run_name = ''
        experiment_name = 'jump'
        load_run = -1
        max_iterations = 1000
        save_interval = 50
        log_interval = 10
        test_interval = None
        checkpoint_interval = 50

def get_a1_jump_config():
    return A1JumpCfg(), A1JumpPPOCfg()