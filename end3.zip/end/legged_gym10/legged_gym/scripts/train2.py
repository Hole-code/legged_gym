import isaacgym
from legged_gym.envs.a1.a1_jump_config import get_a1_jump_config
from legged_gym.envs.base.legged_robot_env import LeggedRobotEnv
from legged_gym.utils.task_utils import task_registry

def train():
    # Получение конфигураций
    cfg, cfg_train = get_a1_jump_config()
    
    # Создание среды
    env = LeggedRobotEnv(cfg, cfg_train)
    
    # Создание задачи
    task_registry.add_task('a1_jump', env)
    
    # Остальная часть кода для настройки и запуска обучения
    # ...

if __name__ == '__main__':
    train()