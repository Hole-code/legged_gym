import gym
import numpy as np
from gym import spaces
from legged_gym.envs.base.legged_robot import LeggedRobot

class SteppingEnv(LeggedRobot):
    def __init__(self, cfg, sim_params, physics_engine, sim_device, headless):
        super().__init__(cfg, sim_params, physics_engine, sim_device, headless)

        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(self.num_obs,))
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.num_act,))

    def reset(self):
        super().reset()
        self._create_terrain()
        return self._get_observations()

    def _create_terrain(self):
        # Создание ступенек от центра до краев карты
        step_height = 0.1  # Высота каждой ступеньки
        step_width = 0.5  # Ширина каждой ступеньки
        num_steps = 10  # Количество ступенек

        for i in range(num_steps):
            x = i * step_width
            z = i * step_height
            self.terrain.add_block(x, 0, z, step_width, step_height)

    def _get_observations(self):
        # Получение наблюдений для агента
        observations = super()._get_observations()
        return observations

    def step(self, action):
        obs, reward, done, info = super().step(action)
        return obs, reward, done, info

    def _compute_reward(self, actions):
        # Ваше определение функции вознаграждения
        return super()._compute_reward(actions)